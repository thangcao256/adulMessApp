package com.thangcao.chatting.listeners;

import com.thangcao.chatting.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
