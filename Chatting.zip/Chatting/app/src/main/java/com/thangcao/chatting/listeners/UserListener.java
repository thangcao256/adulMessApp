package com.thangcao.chatting.listeners;

import com.thangcao.chatting.models.User;

public interface UserListener  {
    void onUserClicked(User user);
}
